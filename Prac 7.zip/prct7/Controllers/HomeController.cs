﻿using System.Web.Mvc;

namespace FeedbackManagement.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
