﻿using System.Collections.Generic;
using System.Web.Mvc;
using FeedbackManagement.Models;

namespace FeedbackManagement.Controllers
{
    public class FeedbackController : Controller
    {
        public ActionResult Index()
        {
            var feedbacks = Session["Feedbacks"] as List<Feedback>;

            if (feedbacks == null)
            {
                feedbacks = new List<Feedback>();
            }

            return View(feedbacks);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Feedback feedback)
        {
            if (ModelState.IsValid)
            {
                var feedbacks = Session["Feedbacks"] as List<Feedback>;

                if (feedbacks == null)
                {
                    feedbacks = new List<Feedback>();
                }

                feedbacks.Add(feedback);

                Session["Feedbacks"] = feedbacks;

                return RedirectToAction("Index");
            }

            return View(feedback);
        }
    }
}